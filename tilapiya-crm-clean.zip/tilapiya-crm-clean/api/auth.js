// Vercel Serverless Function - Dashboard Authentication
// Validates the dashboard password and returns a SIGNED, EXPIRING TOKEN
// (see lib/auth.js) instead of the raw DASHBOARD_SECRET.
// Includes a best-effort per-IP throttle and a fixed delay on failures.

const crypto = require('crypto');
const { issueToken } = require('../lib/auth');

const DASHBOARD_PASSWORD = process.env.DASHBOARD_PASSWORD; // set in Vercel env vars
const DASHBOARD_SECRET = process.env.DASHBOARD_SECRET; // signs the issued tokens
const DASHBOARD_ORIGIN = process.env.DASHBOARD_ORIGIN || '';

// --- Best-effort in-memory throttle (per IP, max 10 fails / 15 min) ---
// NOTE: serverless instances are ephemeral and not shared, so this only
// throttles within a warm instance. It is a speed bump, not a guarantee;
// the 500ms failure delay below applies regardless.
const FAIL_WINDOW_MS = 15 * 60 * 1000;
const MAX_FAILS = 10;
const failMap = new Map(); // ip -> array of fail timestamps

function getClientIp(req) {
  const fwd = req.headers['x-forwarded-for'];
  if (typeof fwd === 'string' && fwd.length > 0) return fwd.split(',')[0].trim();
  return (req.socket && req.socket.remoteAddress) || 'unknown';
}

function isThrottled(ip) {
  const now = Date.now();
  const fails = (failMap.get(ip) || []).filter((t) => now - t < FAIL_WINDOW_MS);
  failMap.set(ip, fails);
  return fails.length >= MAX_FAILS;
}

function recordFail(ip) {
  const fails = failMap.get(ip) || [];
  fails.push(Date.now());
  failMap.set(ip, fails);
  // Keep the map from growing unbounded
  if (failMap.size > 1000) {
    const oldest = failMap.keys().next().value;
    failMap.delete(oldest);
  }
}

module.exports = async function handler(req, res) {
  const allowed = [DASHBOARD_ORIGIN, 'https://tilapiya-crm.vercel.app', 'https://tilapiya-crm.netlify.app'].filter(Boolean);
  const reqOrigin = req?.headers?.origin || '';
  const origin = allowed.includes(reqOrigin) ? reqOrigin : allowed[0] || '*';
